CUDA_VISIBLE_DIVICES=0,1,2 mpirun -np 3 python3 -m train.py \
  --name no_any_sn_gn \
  --dataset_mode scene \
  --dataroot '/home/qingzhongfei/A_scene/SPADE/datasets/train/train/' \
  --correspondence 'ot' \
  --display_freq 2000 \
  --niter 25 \
  --niter_decay 25 \
  --aspect_ratio 1.3333 \
  --maskmix \
  --use_attention \
  --warp_mask_losstype direct \
  --weight_mask 100.0 \
  --PONO \
  --PONO_C \
  --adaptor_nonlocal \
  --ctx_w 0.5 \
  --gpu_ids 0,1,2 \
  --batchSize 9 \
  --label_nc 29 \
  --mcl  \
  --skip_corr  \
  --dists_w 0 \
  --im_height 192 \
  --im_width 256 \
  --checkpoints_dir checkpoints 



# /home/qingzhongfei/A_scene/SPADE/datasets/train/train/
# data/debug_dataset/