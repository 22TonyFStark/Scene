python esrgan.py --n_epochs 50 \
    --batch_size 2 \
    --decay_epoch 25 \
    --hr_height 384 \
    --hr_width 512 \
