import glob
import random
import os
import numpy as np

import jittor
from jittor.dataset.dataset import Dataset
from PIL import Image
from jittor import transform as transforms


# Normalization parameters for pre-trained PyTorch models
mean = np.array([0.485, 0.456, 0.406])
std = np.array([0.229, 0.224, 0.225])

# random select 2000 to calculate mean and std
# mean = [0.445, 0.493, 0.530]
# std = [0.258, 0.253, 0.283]


def denormalize(tensors):
    """ Denormalizes image tensors using mean and std """
    for c in range(3):
        # tensors[:, c].mul_(std[c]).add_(mean[c])
        tensors[:, c] * (std[c]) + (mean[c])
    return jittor.clamp(tensors, 0, 255)


class ImageDataset(Dataset):
    def __init__(self, root, hr_shape):
        super(ImageDataset, self).__init__()
        hr_height, hr_width = hr_shape

        # Transforms for low resolution images and high resolution images
        self.lr_transform = transforms.Compose(
            [
                transforms.Resize((hr_height // 2, hr_width // 2), Image.BICUBIC),
                transforms.ToTensor(),
                transforms.ImageNormalize(mean, std),
            ]
        )
        self.hr_transform = transforms.Compose(
            [
                transforms.Resize((hr_height, hr_width), Image.BICUBIC),
                transforms.ToTensor(),
                transforms.ImageNormalize(mean, std),
            ]
        )

        self.files = sorted(glob.glob(root + "/*.*"))

    def __getitem__(self, index):
        img = Image.open(self.files[index % len(self.files)])
        
        img_lr = self.lr_transform(img)
        img_hr = self.hr_transform(img)
        
        # print(img_lr.shape, img_hr.shape)

        return {"lr": img_lr, "hr": img_hr}

    def __len__(self):
        return len(self.files)
