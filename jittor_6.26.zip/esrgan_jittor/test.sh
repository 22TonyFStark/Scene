# CUDA_VISIBLE_DEVICES=3 python -m torch.distributed.launch --nproc_per_node=1 test_on_image.py  --image_path /home/qingzhongfei/A_scene/unite_jittor/results/no_more_fucking_spe_619_12_256/pre/ --savename jittor_eqlr_sn

#python -m torch.distributed.launch --nproc_per_node=4 test_on_image.py --image_path /home/qingzhongfei/A_scene/UNITE/results/dists_cx0.5_50/pre_70/ --savename unite_70

python test_on_image.py \
    --image_path /home/user/duzongwei/Projects/JTGAN/SPADE_v2/results/jit_sesamediscri_l1_dss_w10/test_latest/images/synthesized_image \
    --residual_blocks 6 \
    --savename pth_test