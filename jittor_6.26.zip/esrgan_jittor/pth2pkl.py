import torch
import pickle

G = torch.load('saved_models/generator_42.pth')

modules = list(G.keys())
# print(modules)

np_G = {}
for module in modules:
    print(module)
    np_G[module] = G[module].cpu().numpy()
file = open('saved_models/generator_42.pkl', 'wb')
pickle.dump(np_G, file)

print('\n\n\n')

file = open('saved_models/generator_42.pkl', 'rb')
g = pickle.load(file)
# print(g.keys())