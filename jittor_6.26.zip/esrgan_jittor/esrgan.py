"""
Super-resolution of CelebA using Generative Adversarial Networks.
The dataset can be downloaded from: https://www.dropbox.com/sh/8oqt9vytwxb3s4r/AADIKlz8PR9zr6Y20qbkunrba/Img/img_align_celeba.zip?dl=0
(if not available there see if options are listed at http://mmlab.ie.cuhk.edu.hk/projects/CelebA.html)
Instrustion on running the script:
1. Download the dataset from the provided link
2. Save the folder 'img_align_celeba' to '../../data/'
4. Run the sript using command 'python3 esrgan.py'

python -m torch.distributed.launch --nproc_per_node=4 esrgan.py
"""

import argparse
import os
from matplotlib import image
import numpy as np
import math
import itertools
import sys

from models import *
from datasets import *

from jittor.misc import save_image
import jittor.nn as nn
import jittor


os.makedirs("images/training", exist_ok=True)
os.makedirs("saved_models", exist_ok=True)

parser = argparse.ArgumentParser()
parser.add_argument("--epoch", type=int, default=0, help="epoch to start training from")
parser.add_argument("--n_epochs", type=int, default=50, help="number of epochs of training")
parser.add_argument("--dataset_name", type=str, default="train_img", help="name of the dataset")
parser.add_argument("--batch_size", type=int, default=1, help="size of the batches")  # 训练4
parser.add_argument("--lr", type=float, default=0.0002, help="adam: learning rate")
parser.add_argument("--b1", type=float, default=0.9, help="adam: decay of first order momentum of gradient")
parser.add_argument("--b2", type=float, default=0.999, help="adam: decay of first order momentum of gradient")
parser.add_argument("--decay_epoch", type=int, default=25, help="epoch from which to start lr decay")
parser.add_argument("--n_cpu", type=int, default=8, help="number of cpu threads to use during batch generation")
parser.add_argument("--hr_height", type=int, default=384, help="high res. image height")
parser.add_argument("--hr_width", type=int, default=512, help="high res. image width")
parser.add_argument("--channels", type=int, default=3, help="number of image channels")
parser.add_argument("--sample_interval", type=int, default=100, help="interval between saving image samples")
parser.add_argument("--checkpoint_interval", type=int, default=2500, help="batch interval between model checkpoints")
parser.add_argument("--residual_blocks", type=int, default=6, help="number of residual blocks in the generator")
parser.add_argument("--warmup_batches", type=int, default=250, help="number of batches with pixel-wise loss only")
parser.add_argument("--lambda_adv", type=float, default=5e-3, help="adversarial loss weight")
parser.add_argument("--lambda_pixel", type=float, default=1e-2, help="pixel-wise loss weight")
parser.add_argument("--local_rank", type=int)
parser.add_argument("--num_workers", type=int, default=8)
opt = parser.parse_args()
print(opt)

# CUDA
os.environ['CUDA_VISIBLE_DEVICES'] = '0,1'
# torch.distributed.init_process_group(backend='nccl')
# world_size = torch.distributed.get_world_size()
# torch.cuda.set_device(opt.local_rank)
# jittor.cudnn.set_max_workspace_ratio(0.0)
jittor.flags.use_cuda = 1 

#device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

hr_shape = (opt.hr_height, opt.hr_width)

# Initialize generator and discriminator
# device = torch.device("cuda", opt.local_rank)


generator = GeneratorRRDB(opt.channels, filters=64, num_res_blocks=opt.residual_blocks, num_upsample=1)
discriminator = Discriminator(input_shape=(opt.channels, *hr_shape))
feature_extractor = FeatureExtractor()

print('G','*'*30)
print(generator)
raise "s"

# generator = torch.nn.parallel.DistributedDataParallel(generator, device_ids=[opt.local_rank],broadcast_buffers=False,find_unused_parameters=True)
# discriminator = torch.nn.parallel.DistributedDataParallel(discriminator, device_ids=[opt.local_rank],broadcast_buffers=False,find_unused_parameters=True)
# feature_extractor = torch.nn.parallel.DistributedDataParallel(feature_extractor, device_ids=[opt.local_rank],broadcast_buffers=False,find_unused_parameters=True)

# Set feature extractor to inference mode
feature_extractor.eval()

# Losses
criterion_GAN = nn.BCEWithLogitsLoss()
criterion_content = nn.L1Loss()
criterion_pixel = nn.L1Loss()

if opt.epoch != 0:
    # Load pretrained models
    generator.load_state_dict(jittor.load("saved_models/generator_%d.pkl" % opt.epoch))
    #discriminator.load_state_dict(torch.load("saved_models/discriminator_%d.pth" % opt.epoch))

# Optimizers
optimizer_G = jittor.optim.Adam(generator.parameters(), lr=opt.lr, betas=(opt.b1, opt.b2))
optimizer_D = jittor.optim.Adam(discriminator.parameters(), lr=opt.lr, betas=(opt.b1, opt.b2))

# Tensor = torch.cuda.FloatTensor if torch.cuda.is_available() else torch.Tensor


# 注意这里path错误的话，train_dataset不会报错，一定要检查清楚!!!
train_dataset = ImageDataset("/home/user/duzongwei/Projects/JTGAN/SPADE/datasets/train/train_img", hr_shape=hr_shape)
dataloader = train_dataset.set_attrs(
    batch_size=opt.batch_size,
    num_workers=opt.num_workers,
)

# torchd Dataloader 的两个属性 jittor中set_attrs没有
# 1. pin_memory 锁页内存，转到GPU的显存更快
# 2. sampler 定义取batch的方法，一般用torch的distributed.DistributedSampler定义一个train_sampler使用
# dataloader = torch.utils.data.DataLoader(
#     dataset=train_dataset,
#     batch_size=opt.batch_size,
#     num_workers=opt.num_workers,
#     pin_memory=True,
#     sampler=train_sampler)


# ----------
#  Training
# ----------

for epoch in range(opt.epoch, opt.n_epochs):
    print(epoch)
    # dataloader.sampler.set_epoch(epoch)
    for i, imgs in enumerate(dataloader):

        batches_done = epoch * len(dataloader) + i

        # Configure model input, with grad
        imgs_lr = jittor.Var(imgs["lr"])
        imgs_hr = jittor.Var(imgs["hr"])
        

        patch_h, patch_w = int(opt.hr_height / 2 ** 4), int(opt.hr_width / 2 ** 4)

        # valid = jittor.ones([imgs_lr.size(0), *discriminator.output_shape]).stop_grad()
        # fake = jittor.zeros([imgs_lr.size(0), *discriminator.output_shape]).stop_grad()
        valid = jittor.ones([imgs_lr.size(0), 1, patch_h, patch_w]).stop_grad()
        fake = jittor.zeros([imgs_lr.size(0), 1, patch_h, patch_w]).stop_grad()
        # valid = Variable(Tensor(np.ones((imgs_lr.size(0), 1, patch_h, patch_w))), requires_grad=False)
        # fake = Variable(Tensor(np.zeros((imgs_lr.size(0), 1, patch_h, patch_w))), requires_grad=False)

        # ------------------
        #  Train Generators
        # ------------------

        optimizer_G.zero_grad()

        # Generate a high resolution image from low resolution input
        gen_hr = generator(imgs_lr)

        # Measure pixel-wise loss against ground truth
        loss_pixel = criterion_pixel(gen_hr, imgs_hr)

        if batches_done < opt.warmup_batches-248:
            # Warm-up (pixel-wise loss only)
            # loss_pixel.backward()
            optimizer_G.backward(loss_pixel)
            optimizer_G.step()
            print(
                "[Epoch %d/%d] [Batch %d/%d] [G pixel: %f]"
                % (epoch, opt.n_epochs, i, len(dataloader), loss_pixel.item())
            )
            continue

        # Extract validity predictions from discriminator
        pred_real = discriminator(imgs_hr).detach()
        pred_fake = discriminator(gen_hr)

        # Adversarial loss (relativistic average GAN)
        try:
            loss_GAN = criterion_GAN(pred_fake - pred_real.mean(0, keepdims=True), valid)
        except:
            print(pred_fake.shape, valid.shape)

        # Content loss
        gen_features = feature_extractor(gen_hr)
        real_features = feature_extractor(imgs_hr).detach()
        loss_content = criterion_content(gen_features, real_features)

        # Total generator loss
        loss_G = loss_content + opt.lambda_adv * loss_GAN + opt.lambda_pixel * loss_pixel

        # loss_G.backward()
        optimizer_G.backward(loss_G)
        optimizer_G.step()

        # ---------------------
        #  Train Discriminator
        # ---------------------

        optimizer_D.zero_grad()

        pred_real = discriminator(imgs_hr)
        pred_fake = discriminator(gen_hr.detach())

        # Adversarial loss for real and fake images (relativistic average GAN)
        loss_real = criterion_GAN(pred_real - pred_fake.mean(0, keepdims=True), valid)
        loss_fake = criterion_GAN(pred_fake - pred_real.mean(0, keepdims=True), fake)

        # Total loss
        loss_D = (loss_real + loss_fake) / 2

        # loss_D.backward()
        optimizer_D.backward(loss_D)
        optimizer_D.step()

        # --------------
        #  Log Progress
        # --------------

        print(
            "[Epoch %d/%d] [Batch %d/%d] [D loss: %f] [G loss: %f, content: %f, adv: %f, pixel: %f]"
            % (
                epoch,
                opt.n_epochs,
                i,
                len(dataloader),
                loss_D.item(),
                loss_G.item(),
                loss_content.item(),
                loss_GAN.item(),
                loss_pixel.item(),
            )
        )

        if batches_done % opt.sample_interval == 0 and jittor.rank == 0:
            # Save image grid with upsampled inputs and ESRGAN outputs
            imgs_lr = nn.interpolate(imgs_lr, scale_factor=2) # default : bilinear
            img_grid = denormalize(jittor.concat((imgs_lr, gen_hr), -1))
            save_image(img_grid, "images/training/%d.png" % batches_done, nrow=1, normalize=False)

        if batches_done % opt.checkpoint_interval == 0 and jittor.rank == 0:
            # Save model checkpoints
            jittor.save(generator.state_dict(), "saved_models/generator_%d.pkl" % epoch)
            jittor.save(discriminator.state_dict(), "saved_models/discriminator_%d.pkl" %epoch)
