import jittor

import pickle
file =  open('checkpoints/all_loss/latest_net_G.pkl', 'rb')
G = pickle.load(file)

modules = list(G.keys())

print(G[modules[0]])