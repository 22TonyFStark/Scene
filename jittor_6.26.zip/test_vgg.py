from jittor import models
from jittor import nn

class VGG19_feature_color_torchversion(nn.Module):
    ''' 
    NOTE: there is no need to pre-process the input 
    input tensor should range in [0,1]
    '''

    def __init__(self, pool='max', vgg_normal_correct=False, ic=3):
        super(VGG19_feature_color_torchversion, self).__init__()
        self.vgg_normal_correct = vgg_normal_correct

        _vgg = models.vgg19().features

        self.conv1_1 = _vgg[0]
        self.conv1_2 = _vgg[2]
        self.conv2_1 = _vgg[5]
        self.conv2_2 = _vgg[7]
        self.conv3_1 = _vgg[10]
        self.conv3_2 = _vgg[12]
        self.conv3_3 = _vgg[14]
        self.conv3_4 = _vgg[16]
        self.conv4_1 = _vgg[19]
        self.conv4_2 = _vgg[21]
        self.conv4_3 = _vgg[23]
        self.conv4_4 = _vgg[25]
        self.conv5_1 = _vgg[28]
        self.conv5_2 = _vgg[30]
        self.conv5_3 = _vgg[32]
        self.conv5_4 = _vgg[34]
        if pool == 'max':
            self.pool1 = _vgg[4]
            self.pool2 = _vgg[9]
            self.pool3 = _vgg[18]
            self.pool4 = _vgg[27]
            self.pool5 = _vgg[36]
        elif pool == 'avg':
            raise "NotImplementedError, by default using max-pooling"

    def execute(self, x, out_keys, preprocess=True):
        ''' 
        NOTE: input tensor should range in [0,1]
        '''
        out = {}
        if preprocess:
            x = vgg_preprocess(x, vgg_normal_correct=self.vgg_normal_correct)
        out['r11'] = nn.relu(self.conv1_1(x))
        out['r12'] = nn.relu(self.conv1_2(out['r11']))
        out['p1'] = self.pool1(out['r12'])
        out['r21'] = nn.relu(self.conv2_1(out['p1']))
        out['r22'] = nn.relu(self.conv2_2(out['r21']))
        out['p2'] = self.pool2(out['r22'])
        out['r31'] = nn.relu(self.conv3_1(out['p2']))
        out['r32'] = nn.relu(self.conv3_2(out['r31']))
        out['r33'] = nn.relu(self.conv3_3(out['r32']))
        out['r34'] = nn.relu(self.conv3_4(out['r33']))
        out['p3'] = self.pool3(out['r34'])
        out['r41'] = nn.relu(self.conv4_1(out['p3']))
        out['r42'] = nn.relu(self.conv4_2(out['r41']))
        out['r43'] = nn.relu(self.conv4_3(out['r42']))
        out['r44'] = nn.relu(self.conv4_4(out['r43']))
        out['p4'] = self.pool4(out['r44'])
        out['r51'] = nn.relu(self.conv5_1(out['p4']))
        out['r52'] = nn.relu(self.conv5_2(out['r51']))
        out['r53'] = nn.relu(self.conv5_3(out['r52']))
        out['r54'] = nn.relu(self.conv5_4(out['r53']))
        out['p5'] = self.pool5(out['r54'])
        return [out[key] for key in out_keys]

