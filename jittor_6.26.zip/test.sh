CUDA_VISIBLE_DEVICES=0,1,2 python test.py \
	--name logsumexp_spectral \
	--dataset_mode scene \
    --dataroot '/home/qingzhongfei/A_scene/test_A/' \
	--correspondence 'ot' \
	--nThreads 0 \
	--use_attention \
	--maskmix \
	--warp_mask_losstype direct \
	--PONO \
	--PONO_C \
	--adaptor_nonlocal \
	--batchSize 24 \
	--aspect_ratio 1.3333 \
	--gpu_ids 0,1,2 \
    --no_pairing_check 

#	--ot_weight \
#	--use_coordconv \
#	--how_many 10