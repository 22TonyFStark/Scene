import torch
import numpy as np

def normalize_gradient(net_D, x, **kwargs):
    """
                     f
    f_hat = --------------------
            || grad_f || + | f |
    """
    x.requires_grad_(True)
    f = net_D(x, **kwargs)
    grad = torch.autograd.grad(
        f, [x], torch.ones_like(f), create_graph=True, retain_graph=True)[0]
    grad_norm = torch.norm(torch.flatten(grad, start_dim=1), p=2, dim=1)
    grad_norm = grad_norm.view(-1, *[1 for _ in range(len(f.shape) - 1)])
    f_hat = (f / (grad_norm + torch.abs(f)))
    return f_hat


ref = torch.randn((2,3,64,64))
np.random.seed(1)
x = torch.tensor(np.random.randn(2,3,64,64), requires_grad=True).to(ref.dtype)


f = torch.nn.Conv2d(3,5,1,bias=False)
np.random.seed(2)
f.weight = torch.nn.Parameter(torch.FloatTensor(np.random.randn(5,3,1,1)))

out = normalize_gradient(f, x)


print(out.flatten()[::1024])

"""
输出
"""