import jittor

a = jittor.Var([[1,2,3],[7,8,9]])

print(jittor.transpose(a,[1,0]))