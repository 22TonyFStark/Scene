import models.networks.loss as loss
import numpy as np
import jittor
import models.pix2pix_model as pix2pix

# GAN Loss

np.random.seed(1)
ganloss = loss.GANLoss('hinge')
inp = np.random.randn(2,4)
print('输入')
print(inp)
print('*'*50)

out = ganloss(inp, True)
print('输出')
print(out)


out = ganloss(inp, False)
print('输出')
print(out)
"""
输入
[[ 1.62434536 -0.61175641 -0.52817175 -1.07296862]
 [ 0.86540763 -2.3015387   1.74481176 -0.7612069 ]]
**************************************************
输出
jt.Var([1.30127934], dtype=float64)
输出
jt.Var([1.04167871], dtype=float64)
"""


# KLD Loss

np.random.seed(1)
kldloss = loss.KLDLoss()

mu = jittor.Var(np.random.randn(2,4))
logvar = jittor.Var(np.random.randn(2,4))
print('输入')
print(mu)
print(logvar)
print('*'*50)

out = kldloss(mu, logvar)
print('输出')
print(out)

"""
输入
jt.Var([[ 1.6243454  -0.6117564  -0.5281718  -1.0729686 ]
 [ 0.86540765 -2.3015387   1.7448118  -0.7612069 ]], dtype=float32)
jt.Var([[ 0.3190391  -0.24937038  1.4621079  -2.0601406 ]
 [-0.3224172  -0.38405436  1.1337694  -1.0998913 ]], dtype=float32)
**************************************************
输出

Compiling Operators(2/2) used: 2.31s eta:    0s 
jt.Var([9.378532], dtype=float32)
"""

G = pix2pix.Pix2PixModel()